import numpy as np
from sol1 import *
from scipy.signal import convolve2d

k = 256


def read_image(filename, representation):
    """Reads an image from file and returns either an RGB or a Grayscale representation of the image.
    Parameters
    ----------
    filename : String
        Path to image file.
    representation : int
        Representation : 1 for grayscale, 2 for RGB.

    Returns
    -------
    np.float64 matrix
        The image normalized between [0,1] in grayscale or RGB representation.
    """

    if representation != 1 and representation != 2:
        raise Exception('Representation must be 1 or 2.')
    im = imread(filename, mode='RGB')
    im_float = im.astype(np.float64)
    im_float /= (k - 1)
    if (representation == 1) & (is_rgb(im_float)):
        im_float = rgb2gray(im_float)
    return im_float


def DFT(signal):
    """
    :param signal: dtype float64
    :return: dtype complex 128 - Complex Fourier signal
    """
    N = signal.shape[1]
    a = np.arange(start=0, stop=N).reshape((N, 1))
    DFT_MATRIX = np.exp((-2*np.pi*1j * a.dot(a.T) / N))
    return signal.dot(DFT_MATRIX)


def IDFT(fourier_signal):
    """
    :param fourier_signal: dtype complex 128
    :return: dtype complex 128 - Complex signal
    """
    N = fourier_signal.shape[1]
    a = np.arange(start=0, stop=N).reshape((N, 1))
    IDFT_MATRIX = np.exp((2*np.pi*1j * a.dot(a.T) / N))
    return (1/N) * fourier_signal.dot(IDFT_MATRIX)


def DFT2(image):
    """
    :param image: dtype float64 grayscale image
    :return:
    """
    return (DFT((DFT (image)).T)).T


def IDFT2(fourier_image):
    """

    :param fourier_image:
    :return:
    """
    return (IDFT((IDFT(fourier_image)).T)).T


def conv_der(im):
    """
    Image derivative magnitude using simple convolution.
    :param im: dtype float64 Input image
    :return: dtype float64 Image derivative magnitude
    """
    x_derivative_kernel = np.array([1, 0, -1]).reshape((3, 1))
    y_derivative_kernel = x_derivative_kernel.T
    dx = convolve2d(im, x_derivative_kernel, mode='same')
    dy = convolve2d(im, y_derivative_kernel, mode='same')

    return np.sqrt(np.abs(dx)**2 + np.abs(dy)**2)


def fourier_der(im):
    """
    :param im:
    :return:
    """
    m = im.shape[0]
    n = im.shape[1]
    u = np.arange(start=-m/2, stop=m/2).reshape((m,1))
    v = np.arange(start=-n/2, stop=n/2).reshape((1,n))
    u = np.tile(u, (1,n))
    v = np.tile(v, (m,1))

    im_f = DFT2(im)
    im_f_shifted = np.fft.fftshift(im_f)

    dx = np.real(((2*np.pi*1j)/(m)) * IDFT2(np.fft.ifftshift(np.multiply(u,im_f))))
    dy = np.real(((2*np.pi*1j)/(n)) * IDFT2(np.fft.ifftshift(np.multiply(im_f, v))))
    return np.sqrt(np.abs(dx)**2 + np.abs(dy)**2)


def blur_spatial(im, kernel_size):
    kernel = generate_gaussian_kernel(kernel_size)
    return convolve2d(im, kernel, mode='same')


def generate_row_binomial_coefficients (size):
    """
    Return a row of binomial coefficients
    :param size: Positive integer >= 2
    :return:
    """
    if size == 1:
        return np.array([1]).reshape((1,1))
    second_row = np.array([1, 1]).reshape((1,2))
    a = np.array([1, 1]).reshape((1,2))
    for i in range(0, size - 2):
        a = convolve2d(a, second_row)
    return a


def generate_gaussian_kernel(size):
    bin = generate_row_binomial_coefficients(size)
    kernel = (1/size**2) * convolve2d(bin, bin.T)
    return kernel


def blur_fourier(im, kernel_size):
    m, n = im.shape
    padded_kernel = np.zeros(im.shape)
    kernel = generate_gaussian_kernel(kernel_size)
    row_start, row_end, col_start, col_end = find_kernel_indices(m, n, kernel_size)
    padded_kernel[row_start:row_end, col_start:col_end] = kernel
    padded_kernel = padded_kernel
    shifted_padded_kernel = np.fft.ifftshift(padded_kernel)
    kernel_f = DFT2(shifted_padded_kernel)
    im_f = DFT2(im)
    return np.real(IDFT2(np.multiply(im_f, kernel_f)))


def find_kernel_indices(m, n, kernel_size):
    c_m = np.floor(m / 2).astype(np.uint)
    c_n = np.floor(n / 2).astype(np.uint)
    k = np.floor(kernel_size / 2).astype(np.uint)
    row_start = c_m - k
    row_end = (c_m + k + 1).astype(np.uint)
    col_start = c_n - k
    col_end = (c_n + k + 1).astype(np.uint)
    return row_start, row_end, col_start, col_end


# signal = np.random.randint(-100, 100, size=(10, 10))
# print (signal)
#1d

# npfft = np.fft.fft(signal)
# dft = DFT(signal)
# print (np.allclose(npfft, dft))
# print ('------------------------------------------------------------------')
# orig_signal = IDFT(dft)
# print (orig_signal)
# print (np.allclose(signal, orig_signal))
# print ('-------------------------------------------------------------------')
# 2d
# npfft2 = np.fft.fft2(signal)
# dft2 = DFT2(signal)
# print(np.allclose(npfft2, dft2))
# print('--------------------------------------------------------------------')
#print('------------------------------------------------------------------')
# orig_signal2 = IDFT2(dft2)
# print (np.allclose(signal, orig_signal2))

# Images
im = read_image("./monkey.jpg", 1)
# im = np.array([[1, 2, 3],
#                [4, 5, 6],
#                [7, 8, 9],
#                [10, 11, 12]])
#im_shifted = np.fft.fftshift(im)
#print (im_shifted)
imshow(im, 1)

#derivative_magnitude = conv_der(im)
#imshow(derivative_magnitude, 1)

#fourier_der = fourier_der(im)
#im_fourier = DFT2(im)
#im_fourier_fft = np.fft.fft2(im)
#print (np.allclose(im_fourier, im_fourier_fft))
#im_f = np.log(1+np.abs(im_f))
#vis = f_vis(im_fourier)

#imshow(fourier_der , 1)

#im_fourier_shifted = np.fft.fftshift (np.real(im_fourier))
#sol1.imshow(im_fourier_shifted, 1)
im = blur_spatial(im, 31)
imshow(im, 1)

im = blur_fourier(im, 31)
imshow(im, 1)
plt.show()
